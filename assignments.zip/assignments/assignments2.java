class publication{
    String title;
    int price;
    int copies;
    void sellcopy(){
    System.out.println("the publication has total copies " +copies);
    }
    };
    class book extends publication{
    String author;
    void ordercopies(int order){
    copies=order;
    }
    
    }
    class magazine extends publication {
    
    int orderqty;
    String currissue;
    void adjustqty(int a){
    orderqty=a;
    }
    void recvNewissue(String a){
    currissue=a;
    }
    
    }
    
    public class assignments2 {
    public static void main(String[] args) {
    book b=new book();
    b.ordercopies(10);
    b.sellcopy();
    
    magazine m=new magazine ();
    m.adjustqty(5);
    m.recvNewissue("1-12-2020");
    
    }
    }